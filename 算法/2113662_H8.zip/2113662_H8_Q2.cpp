#include<iostream>
#include<fstream>
using namespace std;
const int N = 1000000;

int Ftime(int a, int b, int ta, int tb, int ka, int kb) //��(a,b)�ڽڵ�i����С����ʱ��  //�����ű�
{
	int** P0 = new int* [a + 1];  //����
	for (int i = 0; i <= a; i++)
	{
		P0[i] = new int[b + 1];
		for (int j = 0; j <= b; j++)
		{
			P0[i][j] = 0;
		}
	}
	int** P1 = new int* [a + 1];
	for (int i = 0; i <= a; i++)
	{
		P1[i] = new int[b + 1];
		for (int j = 0; j <= b; j++)
		{
			P1[i][j] = 0;
		}
	}
	P0[0][0] = 0; P1[0][0] = 0;  //�߽�ֵ
	for (int i = 1; i <= b; i++)
	{
		P0[0][i] = N;
		P1[0][i] = tb + kb * i * i;
	}
	for (int i = 1; i <= a; i++)
	{
		P0[i][0] = ta + ka * i * i;
		P1[i][0] = N;
	}
	for (int i = 1; i <= a; i++)         //���
	{
		for (int j = 1; j <= b; j++)
		{
			int min1 = N;
			for (int w = 1; w <= i; w++)  //����w
			{
				int temp0 = P1[i - w][j] + ta + ka * w * w;
				min1 = min1 < temp0 ? min1 : temp0;
			}
			P0[i][j] = min1;

			int min2 = N;
			for (int w = 1; w <= j; w++)
			{
				int temp1 = P0[i][j - w] + tb + kb * w * w;
				min2 = min2 < temp1 ? min2 : temp1;
			}
			P1[i][j] = min2;
		}
	}
	int ret = (P0[a][b] < P1[a][b] ? P0[a][b] : P1[a][b]);  //����P1��P0�Ľ�Сֵ

	for (int i = 0; i <= a; i++)
	{
		delete[]P0[i];
		delete[]P1[i];
	}
	delete[]P0;
	delete[]P1;

	return ret;
}

int dp2(int Na, int Nb, int P, int* Ta, int* Tb, int* Ka, int* Kb) //����Na,Nb)������p���ڵ���
{
	int*** C = new int** [P+1];   //�������ʱ�ڵ����仯��������ά�ı�
	for (int i = 0; i <= P; i++)
	{
		C[i] = new int* [Na + 1];
		for (int j = 0; j <= Na; j++)
		{
			C[i][j] = new int[Nb + 1];
			for (int k = 0; k <= Nb; k++)
			{
				C[i][j][k] = 0;
			}
		}
	}
	for (int j = 0; j <= Na; j++)  //�߽�ֵ����ֻ����һ���ڵ�ʱ�������ڴ˽ڵ����С����ʱ�䣨Ftime)
	{
		for (int k = 0; k <= Nb; k++)
		{
			if (j == 0 && k == 0)continue;
			if (j == Na && k == Nb)continue;
			C[1][j][k] = Ftime(j, k, Ta[1], Tb[1], Ka[1], Kb[1]);
		}
	}

	for (int i = 2; i <= P; i++)        //����ά�ı����ӽڵ�2��ʼ���
	{
		for (int j = 0; j <= Na; j++)   //a
		{
			for (int k = 0; k <= Nb; k++)  //b
			{
				int min = N;
				for (int w1 = 0; w1 <= j; w1++)  //w1
				{
					for (int w2 = 0; w2 <= k; w2++)  //w2
					{
						if (w1 == 0 && w2 == 0)continue;
						if (w1 == j && w2 == k)continue;
						int c = C[i - 1][j - w1][k - w2];
						int f = Ftime(w1,w2, Ta[i], Tb[i], Ka[i], Kb[i]);
						 int max = (f<c?c:f);
						if (max < min)min = max;
					}
				}
				C[i][j][k] = min;
			}
		}
	}
	int ret = C[P][Na][Nb];   //���ؽ��
	return ret;
}

int main()
{
	int Na, Nb, p;
	ifstream infile("hpc.in.txt");
	infile >> Na >> Nb >> p;

	int* Ta = new int[p + 1];
	int* Tb = new int[p + 1];
	int* Ka = new int[p + 1];
	int* Kb = new int[p + 1];
	for (int i = 1; i <= p; i++)
	{
		infile >> Ta[i] >> Tb[i] >> Ka[i] >> Kb[i];
	}

	int ret = dp2(Na, Nb, p, Ta, Tb, Ka, Kb);

	ofstream outfile("hpc.out.txt");
	outfile << ret;
	outfile.close();

	return 0;
}